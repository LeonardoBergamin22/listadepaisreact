package br.com.spring.front;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoExercicio01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
