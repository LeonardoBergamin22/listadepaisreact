package br.com.spring.banco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BancoExercicio01Application {

	public static void main(String[] args) {
		SpringApplication.run(BancoExercicio01Application.class, args);
	}

}
